package marvel.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import marvel.view.GameView;
import model.abilities.Ability;
import model.abilities.AreaOfEffect;
import model.abilities.CrowdControlAbility;
import model.abilities.DamagingAbility;
import model.abilities.HealingAbility;
import model.world.Champion;
import model.world.Direction;
import engine.Game;
import engine.Player;
import exceptions.AbilityUseException;
import exceptions.ChampionDisarmedException;
import exceptions.InvalidTargetException;
import exceptions.LeaderAbilityAlreadyUsedException;
import exceptions.LeaderNotCurrentException;
import exceptions.NotEnoughResourcesException;
import exceptions.UnallowedMovementException;

public class GameGUI extends JFrame implements ActionListener{
	private GameView gameView;
	private Game game;
	private Player player1;
	private Player player2;
	ArrayList <JButton> btnChampions;
	ArrayList <JButton> btnChampions2;
	ArrayList <Champion> championsP1;
	ArrayList <Champion> championsP2;
	ArrayList<Champion> temp;
	boolean leader1;
	boolean leader2;

	public GameGUI(){
		gameView = new GameView();
		game = null;
		player1 = null;
		player2 = null;
		gameView.getStart().addActionListener(this);
		championsP1 = new ArrayList<Champion>();
		championsP2 = new ArrayList<Champion>();
	}
	
	public String showAttributes(Champion c){
		String abilities = "";
		int l = 1;
		for(int i=0;i<c.getAbilities().size();i++){
			Ability a = c.getAbilities().get(i);
			abilities+= l + ")" + "Name: " + a.getName() + "\n" +
				"Mana Cost: " + a.getManaCost() + "\n" +
				"Base Cooldown: "  + a.getBaseCooldown() + "\n" +
				"Cast Range: " + a.getCastRange() + "\n" +
				"Area of Effect: " + a.getCastArea() + "\n" +
				"Required Action Points: " + a.getRequiredActionPoints() + "\n";
			
			if(a instanceof CrowdControlAbility)
				abilities += "Effect: \n" +
					"Name: " + ((CrowdControlAbility)a).getEffect().getName() + "\n" + 
					"Type: " + ((CrowdControlAbility)a).getEffect().getType() + "\n" + "\n";
			else if(a instanceof DamagingAbility)
				abilities += "Damage Amount: " + ((DamagingAbility)a).getDamageAmount() + "\n" + "\n";
			else if(a instanceof HealingAbility)
				abilities += "Heal Amount: " + ((HealingAbility)a).getHealAmount() + "\n" + "\n";	
			l++;
		}
		
		String text = "Max Health Points: "+c.getMaxHP() + "\n" +
		"Max Mana: "+ c.getMana() + "\n" + 
		"Max Action Points per Turn: " + c.getMaxActionPointsPerTurn() + "\n" + 
		"Attack Damage: " + c.getAttackDamage() + "\n" +
		"Attack Range: "+c.getAttackRange() + "\n" + 
		"Speed: "+c.getSpeed() + "\n" + "\n" +
		"Abilities: " + "\n"+ abilities;
		return text;
	}
	
	public void actionPerformed(ActionEvent e) {
		if(((JButton)e.getSource()).equals(gameView.getStart())){
			player1 = new Player((String)gameView.getTxtP1().getText());
			player2 = new Player((String)gameView.getTxtP2().getText());
			game = new Game(player1, player2);
			
			btnChampions = new ArrayList<JButton>();
			for(int i=0; i<game.getAvailableChampions().size();i++){
				Champion c = game.getAvailableChampions().get(i);
				JButton btnChamp = new JButton();
				//btnChamp.setText(c.getName());
				btnChamp.setName(c.getName());
				btnChampions.add(btnChamp);
				btnChamp.addActionListener(this);
			}
			gameView.champions(btnChampions);
		}
		if(btnChampions!=null){
		for(int i = 0;i<btnChampions.size();i++){
			if(((JButton)e.getSource()).equals(btnChampions.get(i))){
				gameView.details(showAttributes(game.getAvailableChampions().get(i)), game.getAvailableChampions().get(i));
				gameView.getChoose().addActionListener(this);
				gameView.getLeader().addActionListener(this);
			}
		}
		}	
		if(((JButton)e.getSource()).equals(gameView.getChoose())){
			if(championsP1.size()>=2 && !leader1){
				JOptionPane.showMessageDialog(null,"You already chose 2 champions, you should choose a team Leader");
				return;
			}
			if(championsP1.size()>=3){
				JOptionPane.showMessageDialog(null,"You already chose 3 champions");
				return;
			}
			for(Champion c : championsP1)
				if(c.getName().equals(gameView.getChoose().getName())){
					JOptionPane.showMessageDialog(null,"You already chose this champion.");
					return;
				}
			for (Champion curr : game.getAvailableChampions()){
				if(curr.getName().equals(gameView.getChoose().getName())){
					championsP1.add(curr);
					player1.getTeam().add(curr);
			}}
			System.out.println("Champ 1 btn: " + btnChampions.get(3).getSize().height + " " + btnChampions.get(3).getSize().width);

			gameView.getJ().dispose();

		}
		if(((JButton)e.getSource()).equals(gameView.getLeader())){
			if(championsP1.size()>=3){
				JOptionPane.showMessageDialog(null,"You already chose 3 champions");
				return;
			}
			for(Champion c : championsP1)
				if(c.getName().equals(gameView.getChoose().getName())){
					JOptionPane.showMessageDialog(null,"You already chose this champion.");
					return;
				}
			if(leader1){
				JOptionPane.showMessageDialog(null,"You already chose the leader");
				return;
			}
			for (Champion curr : game.getAvailableChampions()){
				if(curr.getName().equals(gameView.getChoose().getName())){
					player1.setLeader(curr);
					leader1 = true;
					championsP1.add(curr);
					player1.getTeam().add(curr);
			}}
			gameView.getchampions1().addActionListener(this);
			gameView.getJ().dispose();

		}
		//Player 2 starts here
		if(((JButton)e.getSource()).equals(gameView.getchampions1())){
			if(championsP1.size()<3){
				JOptionPane.showMessageDialog(null,"Choose " + (3-championsP1.size()) + " more champions");
				return;
			}
			temp = new ArrayList<Champion>();
			for(Champion x : game.getAvailableChampions()){
				if(!championsP1.contains(x))
					temp.add(x);
			}
			btnChampions2 = new ArrayList<JButton>();
			for(int i=0; i<temp.size();i++){
				Champion c = temp.get(i);
				JButton btnChamp = new JButton();
				//btnChamp.setText(c.getName());
				btnChamp.setName(c.getName());
				btnChampions2.add(btnChamp);
				btnChamp.addActionListener(this);
			}

			gameView.champions2(btnChampions2);
		}
		if(btnChampions2!=null){
			//System.out.println("here");

		for(int i = 0;i<btnChampions2.size();i++){
			if(((JButton)e.getSource()).equals(btnChampions2.get(i))){
				gameView.details2(showAttributes(temp.get(i)), temp.get(i));
				gameView.getChoose2().addActionListener(this);
				gameView.getLeader2().addActionListener(this);
			}
		}
		}	
		
		if(((JButton)e.getSource()).equals(gameView.getChoose2())){
			if(championsP2.size()>=2 && !leader2){
				JOptionPane.showMessageDialog(null,"You already chose 2 champions, you should choose a team Leader");
				return;
			}
			if(championsP2.size()>3){
				JOptionPane.showMessageDialog(null,"You already chose 3 champions");
				return;
			}
			for(Champion c : championsP2)
				if(c.getName().equals(gameView.getChoose2().getName())){
					JOptionPane.showMessageDialog(null,"You already chose this champion.");
					return;
				}
			for (Champion curr : temp){
				if(curr.getName().equals(gameView.getChoose2().getName())){
					championsP2.add(curr);
					player2.getTeam().add(curr);
			}}
			System.out.println("Champ 2 btn: " + btnChampions2.get(5).getSize().height + " " + btnChampions2.get(5).getSize().width);

			gameView.getJ().dispose();
		}
		if(((JButton)e.getSource()).equals(gameView.getLeader2())){
			if(championsP2.size()>3){
				JOptionPane.showMessageDialog(null,"You already chose 3 champions");
				return;
			}
			for(Champion c : championsP2)
				if(c.getName().equals(gameView.getChoose2().getName())){
					JOptionPane.showMessageDialog(null,"You already chose this champion.");
					return;
				}
			if(leader2){
				JOptionPane.showMessageDialog(null,"You already chose the leader");
				return;
			}
			for (Champion curr : temp){
				if(curr.getName().equals(gameView.getChoose2().getName())){
					player2.setLeader(curr);
					leader2 = true;
					championsP2.add(curr);
					player2.getTeam().add(curr);
			}}
			gameView.getchampions2().addActionListener(this);
			gameView.getJ().dispose();
		}
		if(((JButton)e.getSource()).equals(gameView.getchampions2())){
			if(championsP2.size()<3){
				JOptionPane.showMessageDialog(null,"Choose " + (3-championsP2.size()) + " more champions");
				return;
			}
			if(championsP2.size()<3 && !leader2){
				JOptionPane.showMessageDialog(null,"Choose a team leader");
				return;
			}
			System.out.println(player1.getTeam());
			System.out.println(player2.getTeam());
			game = new Game(player1, player2);
			gameView.play(game);
			for (int i=0;i< gameView.getTeam1().size();i++)
				gameView.getTeam1().get(i).addActionListener(this);
			for (int i=0;i< gameView.getTeam2().size();i++)
				gameView.getTeam2().get(i).addActionListener(this);
			gameView.placeOnBoard(game);
			System.out.println("Board: " + gameView.getBoard()[2][3].getSize().height + " " + gameView.getBoard()[2][3].getSize().width);
			gameView.getMove().addActionListener(this);
			gameView.getAttack().addActionListener(this);
			gameView.getCastAbility().addActionListener(this);
			gameView.getUseLeaderAbility().addActionListener(this);
			gameView.getEndTurn().addActionListener(this);
			gameView.getBtnCurrent().addActionListener(this);
		}
		
		if(((JButton)e.getSource()).equals(gameView.getBtnCurrent())){
			gameView.showCurrentInfo(game.getCurrentChampion()); 
			gameView.getCurrentAbilityInfo().addActionListener(this);
			gameView.getCurrentEffectsInfo().addActionListener(this);
		}
		if(((JButton)e.getSource()).equals(gameView.getCurrentAbilityInfo())){
			gameView.showCurrentAbilities(game.getCurrentChampion()); 
		}
		if(((JButton)e.getSource()).equals(gameView.getCurrentEffectsInfo())){
			gameView.showCurrentEffects(game.getCurrentChampion()); 
		}
		if(gameView.getTeam1()!=null){
			for(int i=0;i< gameView.getTeam1().size();i++){
				if(((JButton)e.getSource()).equals(gameView.getTeam1().get(i))){
					if(game.getFirstPlayer().getLeader().equals(game.getFirstPlayer().getTeam().get(i))){
						gameView.showMemberInfo(game.getFirstPlayer().getTeam().get(i),true,true);
					}	
					else{
						gameView.showMemberInfo(game.getFirstPlayer().getTeam().get(i),false,true); 	
					}
					return;
				}
			}
		}

		if(gameView.getTeam2()!=null){
			for(int i=0;i< gameView.getTeam2().size();i++){
				if(((JButton)e.getSource()).equals(gameView.getTeam2().get(i))){
					if(game.getSecondPlayer().getLeader().equals(game.getSecondPlayer().getTeam().get(i))){
						gameView.showMemberInfo(game.getSecondPlayer().getTeam().get(i),true,false);
					}
					else{
						gameView.showMemberInfo(game.getSecondPlayer().getTeam().get(i),false,false);
					}
					return;
				}
			}
		}
		
		// Use Leader Ability Method
		if(((JButton)e.getSource()).equals(gameView.getUseLeaderAbility()))
		{	
			try {
				game.useLeaderAbility();
				gameView.placeOnBoard(game);
				for(int i=0;i<5;i++){
					for(int j=0;j<5;j++){
						if(game.getBoard()[i][j]!=null)
							if(game.getBoard()[i][j] instanceof Champion && ((Champion)game.getBoard()[i][j]).getCurrentHP()==0)
								gameView.getBoard()[i][j].removeAll();
					}
				}
				if(game.checkGameOver()!=null){
					gameView.gameOver(game);
					return;
				}
			} catch (LeaderNotCurrentException e1) {
				JOptionPane.showMessageDialog(null,e1.getMessage());
				e1.printStackTrace();
			} catch (LeaderAbilityAlreadyUsedException e1) {
				JOptionPane.showMessageDialog(null,e1.getMessage());
				e1.printStackTrace();
			}
			
		}
		
		//Attack Method
		if(((JButton)e.getSource()).equals(gameView.getAttack())){
			gameView.attackView();
			gameView.getBtnLeftAttack().addActionListener(this);
			gameView.getBtnRightAttack().addActionListener(this);
			gameView.getBtnDownAttack().addActionListener(this);
			gameView.getBtnUpAttack().addActionListener(this);

		}
		if(((JButton)e.getSource()).equals(gameView.getBtnLeftAttack())){
			try {
				game.attack(Direction.LEFT);
				gameView.placeOnBoard(game);
				if(game.checkGameOver()!=null){
					gameView.gameOver(game);
					return;
				}
			} catch (NotEnoughResourcesException e1) {
				JOptionPane.showMessageDialog(null,e1.getMessage());
				e1.printStackTrace();
			} catch (ChampionDisarmedException e1) {
				JOptionPane.showMessageDialog(null,e1.getMessage());
				e1.printStackTrace();
			} catch (InvalidTargetException e1) {
				JOptionPane.showMessageDialog(null,e1.getMessage());
				e1.printStackTrace();
			}
			gameView.getAttackFrame().dispose();
		}
		if(((JButton)e.getSource()).equals(gameView.getBtnRightAttack())){
			try {
				game.attack(Direction.RIGHT);
				gameView.placeOnBoard(game);
				if(game.checkGameOver()!=null){
					gameView.gameOver(game);
					return;
				}
			} catch (NotEnoughResourcesException e1) {
				JOptionPane.showMessageDialog(null,e1.getMessage());
				e1.printStackTrace();
			} catch (ChampionDisarmedException e1) {
				JOptionPane.showMessageDialog(null,e1.getMessage());
				e1.printStackTrace();
			} catch (InvalidTargetException e1) {
				JOptionPane.showMessageDialog(null,e1.getMessage());
				e1.printStackTrace();
			}
			gameView.getAttackFrame().dispose();
		}
		if(((JButton)e.getSource()).equals(gameView.getBtnDownAttack())){
			try {
				game.attack(Direction.UP);
				gameView.placeOnBoard(game);
				if(game.checkGameOver()!=null){
					gameView.gameOver(game);
					return;
				}
			} catch (NotEnoughResourcesException e1) {
				JOptionPane.showMessageDialog(null,e1.getMessage());
				e1.printStackTrace();
			} catch (ChampionDisarmedException e1) {
				JOptionPane.showMessageDialog(null,e1.getMessage());
				e1.printStackTrace();
			} catch (InvalidTargetException e1) {
				JOptionPane.showMessageDialog(null,e1.getMessage());
				e1.printStackTrace();
			}
			gameView.getAttackFrame().dispose();
		}
		if(((JButton)e.getSource()).equals(gameView.getBtnUpAttack())){
			try {
				game.attack(Direction.DOWN);
				gameView.placeOnBoard(game);
				if(game.checkGameOver()!=null){
					gameView.gameOver(game);
					return;
				}
			} catch (NotEnoughResourcesException e1) {
				JOptionPane.showMessageDialog(null,e1.getMessage());
				e1.printStackTrace();
			} catch (ChampionDisarmedException e1) {
				JOptionPane.showMessageDialog(null,e1.getMessage());
				e1.printStackTrace();
			} catch (InvalidTargetException e1) {
				JOptionPane.showMessageDialog(null,e1.getMessage());
				e1.printStackTrace();
			}
			gameView.getAttackFrame().dispose();
		}
		
		//Move Method
		if(((JButton)e.getSource()).equals(gameView.getMove())){
			gameView.moveView();
			gameView.getBtnLeft().addActionListener(this);
			gameView.getBtnRight().addActionListener(this);
			gameView.getBtnDown().addActionListener(this);
			gameView.getBtnUp().addActionListener(this);
		}
		if(((JButton)e.getSource()).equals(gameView.getBtnLeft())){
			try {
				game.move(Direction.LEFT);
				gameView.placeOnBoard(game);
			} catch (NotEnoughResourcesException e1) {
				JOptionPane.showMessageDialog(null,e1.getMessage());
				e1.printStackTrace();
			} catch (UnallowedMovementException e1) {
				JOptionPane.showMessageDialog(null,e1.getMessage());
				e1.printStackTrace();
			}
			gameView.getMoveFrame().dispose();
		}
		if(((JButton)e.getSource()).equals(gameView.getBtnRight())){
			try {
				game.move(Direction.RIGHT);
				gameView.placeOnBoard(game);

			} catch (NotEnoughResourcesException e1) {
				JOptionPane.showMessageDialog(null,e1.getMessage());
				e1.printStackTrace();
			} catch (UnallowedMovementException e1) {
				JOptionPane.showMessageDialog(null,e1.getMessage());
				e1.printStackTrace();
			}
			gameView.getMoveFrame().dispose();
		}
		if(((JButton)e.getSource()).equals(gameView.getBtnDown())){
			try {
				game.move(Direction.UP);
				gameView.placeOnBoard(game);

			} catch (NotEnoughResourcesException e1) {
				JOptionPane.showMessageDialog(null,e1.getMessage());
				e1.printStackTrace();
			} catch (UnallowedMovementException e1) {
				JOptionPane.showMessageDialog(null,e1.getMessage());
				e1.printStackTrace();
			}
			gameView.getMoveFrame().dispose();
		}
		if(((JButton)e.getSource()).equals(gameView.getBtnUp())){
			try {
				game.move(Direction.DOWN);
				gameView.placeOnBoard(game);
			} catch (NotEnoughResourcesException e1) {
				JOptionPane.showMessageDialog(null,e1.getMessage());
				e1.printStackTrace();
			} catch (UnallowedMovementException e1) {
				JOptionPane.showMessageDialog(null,e1.getMessage());
				e1.printStackTrace();
			}
			gameView.getMoveFrame().dispose();
		}
		
		if(((JButton)e.getSource()).equals(gameView.getEndTurn())){
			game.endTurn();
			gameView.updatePlay(game);
		}
		
		if(((JButton)e.getSource()).equals(gameView.getCastAbility())){
			gameView.castAbilityView(game);
			for(JButton b : gameView.getChampAbilities())
				b.addActionListener(this);
		}
		
		if(gameView.getChampAbilities()!=null && gameView.getChampAbilities().contains((JButton)e.getSource())){
			for(Ability a : game.getAvailableAbilities()){
				if(a.getName().equals(((JButton)e.getSource()).getName())){
				if(!(a.getCastArea().equals(AreaOfEffect.SINGLETARGET)) && !(a.getCastArea().equals(AreaOfEffect.DIRECTIONAL))){
					try {
						game.castAbility(a);
						gameView.placeOnBoard(game);
						if(game.checkGameOver()!=null){
							gameView.gameOver(game);
							return;
						}
					} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog(null,e1.getMessage());
						e1.printStackTrace();
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog(null,e1.getMessage());
						e1.printStackTrace();
					} catch (CloneNotSupportedException e1) {
						JOptionPane.showMessageDialog(null,e1.getMessage());
						e1.printStackTrace();
					}
					gameView.getCastFrame().dispose();
				}
				else{
					gameView.useAbility(a);
					if(a.getCastArea().equals(AreaOfEffect.SINGLETARGET))
						gameView.getEnter().addActionListener(this);
					else if(a.getCastArea().equals(AreaOfEffect.DIRECTIONAL)){
						gameView.getBtnLeftArea().addActionListener(this);
						gameView.getBtnRightArea().addActionListener(this);
						gameView.getBtnDownArea().addActionListener(this);
						gameView.getBtnUpArea().addActionListener(this);
					}
					}
				}
			}
		}
		
		if(((JButton)e.getSource()).equals(gameView.getBtnLeftArea())){
			for(Ability a : game.getCurrentChampion().getAbilities()){
				if(a.getName().equals(gameView.getBtnLeftArea().getName())){
					try {
						game.castAbility(a, Direction.LEFT);
						gameView.placeOnBoard(game);
						if(game.checkGameOver()!=null){
							gameView.gameOver(game);
							return;
						}
					} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog(null,e1.getMessage());
						e1.printStackTrace();
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog(null,e1.getMessage());
						e1.printStackTrace();
					} catch (CloneNotSupportedException e1) {
						JOptionPane.showMessageDialog(null,e1.getMessage());
						e1.printStackTrace();
					}
					return;
				}		
			}
			gameView.getDirecFrame().dispose();
		}
		
		if(((JButton)e.getSource()).equals(gameView.getBtnRightArea())){
			for(Ability a : game.getCurrentChampion().getAbilities()){
				if(a.getName().equals(gameView.getBtnRightArea().getName())){
					try {
						game.castAbility(a, Direction.RIGHT);
						gameView.placeOnBoard(game);
						if(game.checkGameOver()!=null){
							gameView.gameOver(game);
							return;
						}
					} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog(null,e1.getMessage());
						e1.printStackTrace();
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog(null,e1.getMessage());
						e1.printStackTrace();
					} catch (CloneNotSupportedException e1) {
						JOptionPane.showMessageDialog(null,e1.getMessage());
						e1.printStackTrace();
					}
					return;
				}
					
			}
			gameView.getDirecFrame().dispose();
		}
		if(((JButton)e.getSource()).equals(gameView.getBtnDownArea())){
			for(Ability a : game.getCurrentChampion().getAbilities()){
				if(a.getName().equals(gameView.getBtnDownArea().getName())){
					try {
						game.castAbility(a, Direction.UP);
						gameView.placeOnBoard(game);
						if(game.checkGameOver()!=null){
							gameView.gameOver(game);
							return;
						}
					} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog(null,e1.getMessage());
						e1.printStackTrace();
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog(null,e1.getMessage());
						e1.printStackTrace();
					} catch (CloneNotSupportedException e1) {
						JOptionPane.showMessageDialog(null,e1.getMessage());
						e1.printStackTrace();
					}
					return;
				}
					
			}
			gameView.getDirecFrame().dispose();
		}
		if(((JButton)e.getSource()).equals(gameView.getBtnUpArea())){
			for(Ability a : game.getCurrentChampion().getAbilities()){
				if(a.getName().equals(gameView.getBtnUpArea().getName())){
					try {
						game.castAbility(a, Direction.DOWN);
						gameView.placeOnBoard(game);
						if(game.checkGameOver()!=null){
							gameView.gameOver(game);
							return;
						}
					} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog(null,e1.getMessage());
						e1.printStackTrace();
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog(null,e1.getMessage());
						e1.printStackTrace();
					} catch (CloneNotSupportedException e1) {
						JOptionPane.showMessageDialog(null,e1.getMessage());
						e1.printStackTrace();
					}
					return;
				}
					
			}
			gameView.getDirecFrame().dispose();
		}
		
		if(((JButton)e.getSource()).equals(gameView.getEnter())){
			int x = Integer.parseInt(gameView.getTargetX().getText());
			int y = Integer.parseInt(gameView.getTargetY().getText());
			for(Ability a : game.getAvailableAbilities()){
				if(a.getName().equals(gameView.getTargetX().getName())){
					try {
						game.castAbility(a, x, y);
						gameView.placeOnBoard(game);
						if(game.checkGameOver()!=null){
							gameView.gameOver(game);
							return;
						}
					} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog(null,e1.getMessage());
						e1.printStackTrace();
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog(null,e1.getMessage());
						e1.printStackTrace();
					} catch (InvalidTargetException e1) {
						JOptionPane.showMessageDialog(null,e1.getMessage());
						e1.printStackTrace();
					} catch (CloneNotSupportedException e1) {
						JOptionPane.showMessageDialog(null,e1.getMessage());
						e1.printStackTrace();
					}
					return;
				}
			}
			gameView.getSingFrame().dispose();
		}
		
	}
	public static void main (String[] args){
		GameGUI g = new GameGUI();
		
	}
}
