package marvel.view;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import engine.Game;
import engine.Player;
import engine.PriorityQueue;
import exceptions.LeaderAbilityAlreadyUsedException;
import exceptions.LeaderNotCurrentException;

import javax.imageio.ImageIO;
import javax.swing.*;

import model.abilities.Ability;
import model.abilities.AreaOfEffect;
import model.abilities.CrowdControlAbility;
import model.abilities.DamagingAbility;
import model.abilities.HealingAbility;
import model.effects.EffectType;
import model.world.*;



public class GameView extends JFrame{
	private JButton start;
	private JPanel pnlNames;
	private JPanel pnlChampions;
	private JPanel pnlChampions2;
	//private ArrayList<String> names;
	private JFrame j;
	private JButton choose;
	private JButton leader;
	private JButton choose2;
	private JButton leader2;
	private JButton champions1;
	private JButton champions2;
	private JTextArea chooseChampions;
	private JTextArea chooseChampions2;
	private JTextField txtP1;
	private JTextField txtP2;
	private JPanel currentChamp;
	private JButton champ;
	private JPanel turn;
	private JTextArea turns;
	private ArrayList<JButton> team1;
	private ArrayList<JButton> team2;
	private static JPanel[][] board;
	private JButton currentAbilityInfo;
	private JButton currentEffectsInfo;
	private JButton champEffectsInfo;
	private JButton btnCurrent, move, attack, castAbility,useLeaderAbility,endTurn;
	private JButton btnLeft, btnRight, btnDown, btnUp;
	private JFrame attackFrame, moveFrame, singFrame, direcFrame, castFrame;
	private JButton btnLeftAttack, btnRightAttack, btnDownAttack, btnUpAttack;
	private JButton btnLeftArea, btnRightArea, btnDownArea, btnUpArea;
	private ArrayList<JButton> champAbilities;
	private JTextField targetX, targetY;
	private JButton enter;
	private JLabel leaderSecond, leaderFirst; 
	
	/*public ArrayList<String> getNames(){
		return names;
	}*/
	public JButton getStart(){
		return start;
	}
	public JFrame getJ(){
		return j;
	}
	public JButton getChoose(){
		return choose;
	}
	public JButton getLeader(){
		return leader;
	}
	public JButton getchampions1(){
		return champions1;
	}
	public JButton getChoose2(){
		return choose2;
	}
	public JButton getLeader2(){
		return leader2;
	}
	public JButton getchampions2(){
		return champions2;
	}
	public JTextField getTxtP1(){
		return txtP1;
	}
	public JTextField getTxtP2(){
		return txtP2;
	}
	public JPanel getTurn(){
		return turn;
	}
	public JTextArea getTurns(){
		return turns;
	}
	public JPanel getCurrentChamp(){
		return currentChamp;
	}
	public JButton getChamp(){
		return champ;
	}
	public ArrayList<JButton> getTeam1(){
		return team1;
	}
	public ArrayList<JButton> getTeam2(){
		return team2;
	}
	public JButton getCurrentAbilityInfo(){
		return currentAbilityInfo;
	}
	public JButton getCurrentEffectsInfo(){
		return currentEffectsInfo;
	}
	public JButton getChampEffectsInfo(){
		return champEffectsInfo;
	}
	public JFrame getAttackFrame(){
		return attackFrame;
	}
	public JFrame getMoveFrame(){
		return moveFrame;
	}
	public JFrame getDirecFrame(){
		return direcFrame;
	}
	public JFrame getSingFrame(){
		return singFrame;
	}
	public JFrame getCastFrame(){
		return castFrame;
	}
	public JButton getMove(){
		return move;
	}
	public JButton getAttack(){
		return attack;
	}
	public JButton getCastAbility(){
		return castAbility;
	}
	public JButton getUseLeaderAbility(){
		return useLeaderAbility;
	}
	public JButton getEndTurn(){
		return endTurn;
	}
	public JPanel[][] getBoard(){
		return board;
	}
	public JButton getBtnCurrent(){
		return btnCurrent;
	}
	public JButton getBtnLeft(){
		return btnLeft;
	}
	public JButton getBtnRight(){
		return btnRight;
	}
	public JButton getBtnDown(){
		return btnDown;
	}
	public JButton getBtnUp(){
		return btnUp;
	}
	public JButton getBtnLeftAttack(){
		return btnLeftAttack;
	}
	public JButton getBtnRightAttack(){
		return btnRightAttack;
	}
	public JButton getBtnDownAttack(){
		return btnDownAttack;
	}
	public JButton getBtnUpAttack(){
		return btnUpAttack;
	}
	public JButton getBtnLeftArea(){
		return btnLeftArea;
	}
	public JButton getBtnRightArea(){
		return btnRightArea;
	}
	public JButton getBtnDownArea(){
		return btnDownArea;
	}
	public JButton getBtnUpArea(){
		return btnUpArea;
	}
	public JTextField getTargetX(){
		return targetX;
	}
	public JTextField getTargetY(){
		return targetY;
	}
	public ArrayList<JButton> getChampAbilities(){
		return champAbilities;
	}
	public JButton getEnter(){
		return enter;
	}
	
	public GameView(){
		setTitle("Marvel");
		this.setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setBounds(0, 0, 2000, 1100);
		setLayout(null);
		setBackground(Color.BLUE);
		enterNames();
		
		this.revalidate();
		this.repaint();
		
	}
	public void enterNames(){
		pnlNames = new JPanel();
		pnlNames.setBounds(0,0,2000,1100);
		pnlNames.setLayout(null);
		
		ImageIcon background = new ImageIcon(this.getClass().getResource("background.jfif"));
		JLabel b = new JLabel();
		b.setBounds(0,0,2000,1100);
		b.setIcon(background);
		pnlNames.add(b);
		
		JLabel labelP1 = new JLabel();
		JLabel labelP2 = new JLabel();
		labelP1.setForeground(Color.WHITE);
		labelP1.setBackground(Color.RED);
		labelP2.setForeground(Color.WHITE);
		labelP2.setBackground(Color.BLUE);
		txtP1 = new JTextField();
		txtP2 = new JTextField();
		labelP1.setBounds(600,450,450,130);
		labelP1.setFont(new Font(Font.MONOSPACED, Font.BOLD, 28));
		txtP1.setBounds(600,600,300,100);
		txtP1.setFont(new Font(Font.MONOSPACED, Font.BOLD, 28));
		
		labelP2.setBounds(1000,450,450,130);
		labelP2.setFont(new Font(Font.MONOSPACED, Font.BOLD, 28));
		txtP2.setBounds(1000,600,300,100);
		txtP2.setFont(new Font(Font.MONOSPACED, Font.BOLD, 28));
		
		//names = new ArrayList<String>();
		labelP1.setText("Enter First Player: ");
		labelP2.setText("Enter Second Player: ");
		
		pnlNames.setVisible(true);
		b.add(labelP1);
		b.add(txtP1);
		b.add(labelP2);
		b.add(txtP2);
		add(pnlNames);
		//names.add(txtP1.getText());
		//names.add(txtP2.getText());
	
		start = new JButton();
		start.setBounds(800, 800, 300, 120);
		start.setIcon(new ImageIcon("Start.jpg"));
		pnlNames.add(start);
		
		this.repaint();
		this.revalidate();
	}


	public void champions(ArrayList<JButton> j){
		pnlNames.setVisible(false);
		chooseChampions = new JTextArea("             Select first player's champions" + "\n" + "        Choose 1 Team Leader and 2 Team Members");
		chooseChampions.setBounds(500,0,1000,100);
		chooseChampions.setForeground(Color.RED);
		chooseChampions.setFont(new Font(Font.MONOSPACED, Font.BOLD, 28));
		chooseChampions.setEditable(false);
		add(chooseChampions);
		pnlChampions = new JPanel();
		pnlChampions.setBounds(0,100,2000,800);
		pnlChampions.setLayout(new GridLayout(3,5));
		ImageIcon s = null;
		for(int i=0;i<j.size();i++){
			switch(j.get(i).getName()){
			case "Captain America" : s = new ImageIcon("CaptainAmerica.png");break;
			case "Deadpool" : s = new ImageIcon("Deadpool.png");break;
			case "Dr Strange" : s = new ImageIcon("DrStrange.png");break;
			case "Electro" : s = new ImageIcon("Electro.jpg");break;
			case "Ghost Rider" : s = new ImageIcon("GhostRider.jpg");break;
			case "Hela" : s = new ImageIcon("Hela.png");break;
			case "Hulk" : s = new ImageIcon("Hulk.jpg");break;
			case "Iceman" : s = new ImageIcon("Iceman.png");break;
			case "Ironman" : s = new ImageIcon("Ironman.jpg");break;
			case "Loki" : s = new ImageIcon("Loki.png");break;
			case "Quicksilver" : s = new ImageIcon("Quicksilver.png");break;
			case "Spiderman" : s = new ImageIcon("Spiderman1.jfif");break;
			case "Thor" : s = new ImageIcon("Thor1.jfif");break;
			case "Venom" : s = new ImageIcon("Venom.jpg");break;
			case "Yellow Jacket" : s = new ImageIcon("YellowJacket.jpg");break;
			default:break;
			}
			j.get(i).setIcon(s);
			pnlChampions.add(j.get(i));
		}
		pnlChampions.setVisible(true);
		add(pnlChampions);
		champions1 = new JButton("Next");
		champions1.setBounds(850,915,200,100);
		champions1.setBackground(Color.RED);
		champions1.setForeground(Color.WHITE);
		champions1.setFont(new Font(Font.MONOSPACED, Font.BOLD, 20));
		champions1.setVisible(true);
		add(champions1);
		
		this.revalidate();
		this.repaint();
	}
	
	public void details(String s, Champion c){
		j = new JFrame();
		j.setBounds(500,25,800,1000);
		j.setVisible(true);
		JPanel details = new JPanel();
		details.setBounds(0,0,800,1000);
		details.setLayout(null);
		JTextArea text = new JTextArea();
		text.setText(s);
		text.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 16));
		text.setBounds(150,25,500,800);
		text.setEditable(false);
		details.add(text);
		choose = new JButton("Add as team member");
		choose.setBounds(50,850,300,80);
		choose.setName(c.getName());
		choose.setForeground(Color.WHITE);
		choose.setBackground(Color.RED);
		choose.setFont(new Font(Font.MONOSPACED, Font.BOLD, 18));
		leader = new JButton("Add as team leader");
		leader.setBounds(450,850,300,80);
		leader.setName(c.getName());
		leader.setForeground(Color.WHITE);
		leader.setBackground(Color.RED);
		leader.setFont(new Font(Font.MONOSPACED, Font.BOLD, 18));
		details.add(choose);
		details.add(leader);
		j.setTitle(c.getName());
		j.add(details);
	}
	
	//Player 2 starts here
	public void champions2(ArrayList<JButton> j){
		pnlChampions.setVisible(false);
		chooseChampions.setVisible(false);
		champions1.setVisible(false);
		chooseChampions2 = new JTextArea("            Select second player's champions" + "\n" + "        Choose 1 Team Leader and 2 Team Members");
		chooseChampions2.setBounds(500,0,1000,100);
		chooseChampions2.setForeground(Color.BLUE);
		chooseChampions2.setFont(new Font(Font.MONOSPACED, Font.BOLD, 28));
		chooseChampions2.setEditable(false);
		add(chooseChampions2);
		pnlChampions2 = new JPanel();
		pnlChampions2.setBounds(0,100,2000,800);
		pnlChampions2.setLayout(new GridLayout(3,4));
		ImageIcon s = null;
		for(int i=0;i<j.size();i++){
			switch(j.get(i).getName()){
			case "Captain America" : s = new ImageIcon("CaptainAmerica.png");break;
			case "Deadpool" : s = new ImageIcon("Deadpool.png");break;
			case "Dr Strange" : s = new ImageIcon("DrStrange.png");break;
			case "Electro" : s = new ImageIcon("Electro.jpg");break;
			case "Ghost Rider" : s = new ImageIcon("GhostRider.jpg");break;
			case "Hela" : s = new ImageIcon("Hela.png");break;
			case "Hulk" : s = new ImageIcon("Hulk.jpg");break;
			case "Iceman" : s = new ImageIcon("Iceman.png");break;
			case "Ironman" : s = new ImageIcon("Ironman.jpg");break;
			case "Loki" : s = new ImageIcon("Loki.png");break;
			case "Quicksilver" : s = new ImageIcon("Quicksilver.png");break;
			case "Spiderman" : s = new ImageIcon("Spiderman1.jfif");break;
			case "Thor" : s = new ImageIcon("Thor1.jfif");break;
			case "Venom" : s = new ImageIcon("Venom.jpg");break;
			case "Yellow Jacket" : s = new ImageIcon("YellowJacket.jpg");break;
			default:break;
			}
			j.get(i).setIcon(s);
			pnlChampions2.add(j.get(i));
		}
		pnlChampions2.setVisible(true);
		add(pnlChampions2);
		
		champions2 = new JButton("Next");
		champions2.setBounds(850,915,200,100);
		champions2.setBackground(Color.BLUE);
		champions2.setForeground(Color.WHITE);
		champions2.setFont(new Font(Font.MONOSPACED, Font.BOLD, 20));
		add(champions2);
		champions2.setVisible(true);
		
		this.revalidate();
		this.repaint();
	}
	public void details2(String s, Champion c){
		j = new JFrame();
		j.setBounds(500,25,800,1000);
		j.setVisible(true);
		JPanel details = new JPanel();
		details.setBounds(0,0,800,1000);
		details.setLayout(null);
		JTextArea text = new JTextArea();
		text.setText(s);
		text.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 16));
		text.setBounds(150,25,500,800);
		text.setEditable(false);
		details.add(text);
		choose2 = new JButton("Add as team member");
		choose2.setBounds(50,850,300,80);
		choose2.setName(c.getName());
		choose2.setForeground(Color.WHITE);
		choose2.setBackground(Color.BLUE);
		choose2.setFont(new Font(Font.MONOSPACED, Font.BOLD, 18));
		leader2 = new JButton("Add as team leader");
		leader2.setBounds(450,850,300,80);
		leader2.setName(c.getName());
		leader2.setForeground(Color.WHITE);
		leader2.setBackground(Color.BLUE);
		leader2.setFont(new Font(Font.MONOSPACED, Font.BOLD, 18));
		details.add(choose2);
		details.add(leader2);
		j.setTitle(c.getName());
		j.add(details);
	}
	
	public void updatePlay(Game g){
		getBtnCurrent().setText(g.getCurrentChampion().getName());
		String s = "Turn Order: ";
		PriorityQueue temp = new PriorityQueue(6);
		while(!g.getTurnOrder().isEmpty()){
			Champion c = (Champion)g.getTurnOrder().peekMin();
			s+= c.getName() + ", ";
			temp.insert(g.getTurnOrder().remove());
		}
		s+=".";
		while(!temp.isEmpty())
			g.getTurnOrder().insert(temp.remove());
		getTurns().setText(s);
		
		for(int i=0;i<team1.size();i++){
			for(int j=0;j<g.getFirstPlayer().getTeam().size();j++)
				if(!g.getFirstPlayer().getTeam().get(i).getName().equals(team1.get(i).getName())){
					team1.get(i).setVisible(false);
				team1.remove(i);
				i--;
			}	
		}
		
		for(int i=0;i<team2.size();i++){
			for(int j=0;j<g.getSecondPlayer().getTeam().size();j++)	
				if(!g.getSecondPlayer().getTeam().get(i).getName().equals(team2.get(i).getName())){
					team2.get(i).setVisible(false);
				team2.remove(i);
				i--;
			}	
		}
		
		String s1 = "";
		if(g.isFirstLeaderAbilityUsed())
			s1+= "used";
		else
			s1+= "not used";
		leaderFirst.setText("Leader Ability: " +s1);
		
		String s2 = "";
		if(g.isSecondLeaderAbilityUsed())
			s2+= "used";
		else
			s2+= "not used";
		leaderSecond.setText("Leader Ability: " +s2);    
      
		
		revalidate();
		repaint();
	}
	
	public void play(Game g){
		pnlChampions2.setVisible(false);
		chooseChampions2.setVisible(false);
		champions2.setVisible(false);
		JPanel grid = new JPanel();
		grid.setBounds(350,100,1200,850);
		grid.setLayout(new GridLayout(5,5));
		setLayout(null);
		
		board = new JPanel[5][5];
		for(int m = 0; m < 5; m++)
			for(int n = 0; n < 5;n++){
				board[m][n] = new JPanel();
				board[m][n].setBorder(BorderFactory.createLineBorder(Color.BLACK));
				board[m][n].setLayout(null);
				grid.add(board[m][n]);
			}
		
		JPanel player1 = new JPanel();
		player1.setBounds(0,0,350,1000);
		player1.setLayout(null);
		JTextArea txt1 = new JTextArea("Player1 : " + "\n" + g.getFirstPlayer().getName() +"\n"+ "---------------------------" +"\n");
		txt1.setBounds(0,0,350,100);
		txt1.setEditable(false);
		txt1.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 20));
		player1.add(txt1);
		int x1 = 1;
		team1 = new ArrayList<JButton>();
		for(int i = 0;i<g.getFirstPlayer().getTeam().size();i++){
			champ = new JButton(g.getFirstPlayer().getTeam().get(i).getName());
			champ.setName(g.getFirstPlayer().getTeam().get(i).getName());
			champ.setBounds(x1, 100, 118, 100);
			if(g.getFirstPlayer().getTeam().get(i).equals(g.getFirstPlayer().getLeader()))
				champ.setBackground(Color.RED);
			player1.add(champ);
			team1.add(champ);
			x1+=118;
		}
		
		String s1 = "";
		if(g.isFirstLeaderAbilityUsed())
			s1+= " used";
		else
			s1+= "not used";
		leaderFirst = new JLabel("Leader Ability: " + s1);    
        leaderFirst.setBounds(50,250,300,100);
        leaderFirst.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 18));
		player1.add(leaderFirst);
		
		JPanel player2 = new JPanel();
		player2.setBounds(1550,0,400,1000);
		player2.setLayout(null);
		JTextArea txt2 = new JTextArea("Player2 : " +"\n" + g.getSecondPlayer().getName() +"\n"+ "---------------------------" +"\n");
		txt2.setBounds(0,0,350,100);
		txt2.setEditable(false);
		txt2.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 20));
		player2.add(txt2);
		int x2 = 1;
		team2=new ArrayList<JButton>();
		for(int i = 0;i<g.getSecondPlayer().getTeam().size();i++){
			champ = new JButton(g.getSecondPlayer().getTeam().get(i).getName());
			champ.setName(g.getSecondPlayer().getTeam().get(i).getName());
			champ.setBounds(x2, 100, 118, 100);
			if(g.getSecondPlayer().getTeam().get(i).equals(g.getSecondPlayer().getLeader()))
				champ.setBackground(Color.BLUE);
			player2.add(champ);
			team2.add(champ);
			x2+=118;
		}
		String s2 = "";
		if(g.isSecondLeaderAbilityUsed())
			s2+= "used";
		else
			s2+= "not used";
		leaderSecond = new JLabel("Leader Ability: " +s2);    
        leaderSecond.setBounds(50,250,300,100);
        leaderSecond.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 18));
		player2.add(leaderSecond);
		
		
		currentChamp = new JPanel();
		currentChamp.setBounds(350, 0, 1200,100);
		currentChamp.setLayout(null);
		btnCurrent = new JButton(g.getCurrentChampion().getName() + "");
		move = new JButton("Move");
		attack = new JButton("Attack");
		castAbility = new JButton("Cast Ability");
		useLeaderAbility = new JButton("Use Leader Ability");
		endTurn = new JButton("End Turn");
		
		btnCurrent.setBounds(0,0,200,100);
		move.setBounds(200,0,200,100);
		attack.setBounds(400,0,200,100);
		castAbility.setBounds(600,0,200,100);
		useLeaderAbility.setBounds(800,0,200,100);
		endTurn.setBounds(1000,0,200,100);
		currentChamp.add(btnCurrent);
		currentChamp.add(move);
		currentChamp.add(attack);
		currentChamp.add(castAbility);
		currentChamp.add(useLeaderAbility);
		currentChamp.add(endTurn);
		
		turn = new JPanel();
		turn.setBounds(350,950, 1200, 100);
		turn.setVisible(true);
		String s = "Turn Order: ";
		PriorityQueue temp = new PriorityQueue(6);
		while(!g.getTurnOrder().isEmpty()){
			Champion c = (Champion)g.getTurnOrder().peekMin();
			s+= c.getName() + ", ";
			temp.insert(g.getTurnOrder().remove());
		}
		s+=".";
		while(!temp.isEmpty())
			g.getTurnOrder().insert(temp.remove());
		turns = new JTextArea(s);
		turns.setBounds(50,50,1100,100);
		turns.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 18));
		turn.add(turns);
		
		grid.setVisible(true);
		player1.setVisible(true);
		player2.setVisible(true);
		currentChamp.setVisible(true);
		add(player1);
		add(grid);
		add(currentChamp);
		add(player2);
		add(turn);
		
		this.revalidate();
		this.repaint();
	}
	
	public void placeOnBoard(Game g){
		for(int i = 0; i<5 ;i++){
			for(int j = 0; j<5 ;j++){
				if(g.getBoard()[i][j]!=null){
				if(g.getBoard()[i][j] instanceof Cover){
					board[i][j].removeAll();
					Cover co = (Cover)g.getBoard()[i][j];
					JLabel cor = new JLabel("("+i+","+j+")");
					cor.setBounds(90, 5, 80, 20);
					cor.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 18));
					board[i][j].add(cor);

					JLabel l = new JLabel("Cover");
					l.setBounds(90, 20, 80, 20);
					l.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 18));
					board[i][j].add(l);
					JProgressBar pb = new JProgressBar(0,999);
					pb.setValue(co.getCurrentHP());
					pb.setString("" + co.getCurrentHP());
					pb.setStringPainted(true);
					pb.setBounds(45, 40, 150, 30);
					board[i][j].add(pb);
					ImageIcon s = new ImageIcon("Cover.jfif");
					l = new JLabel();
					l.setBounds(70, 60, 100, 100);
					l.setIcon(s);
					board[i][j].add(l);
				}
				else if(g.getBoard()[i][j] instanceof Champion){
					board[i][j].removeAll();
					Champion c = ((Champion)g.getBoard()[i][j]);
					JLabel cor = new JLabel("("+i+","+j+")");
					cor.setBounds(90, 5, 80, 20);
					cor.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 18));
					board[i][j].add(cor);
					
					if(g.getFirstPlayer().getTeam().contains(c)){
						JLabel l = new JLabel("Player 1: " + c.getName());
						l.setBounds(30, 20, 200, 20);
						l.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 16));
						l.setForeground(Color.RED);
						board[i][j].add(l);
					}
					else if(g.getSecondPlayer().getTeam().contains(c)){
						JLabel l = new JLabel("Player 2: " + c.getName());
						l.setBounds(30, 20, 200, 20);
						l.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 16));
						l.setForeground(Color.BLUE);
						board[i][j].add(l);
					}
					JProgressBar pb = new JProgressBar(0,c.getMaxHP());
					pb.setValue(c.getCurrentHP());
					pb.setString("" + c.getCurrentHP());
					pb.setStringPainted(true);
					pb.setBounds(45, 40, 150, 25);
					board[i][j].add(pb);
					
					ImageIcon s = null;
					switch(c.getName()){
					case "Captain America" : s = new ImageIcon("CaptainAmericab.png");break;
					case "Deadpool" : s = new ImageIcon("Deadpoolb.png");break;
					case "Dr Strange" : s = new ImageIcon("DrStrangeb.png");break;
					case "Electro" : s = new ImageIcon("Electrob.jfif");break;
					case "Ghost Rider" : s = new ImageIcon("GhostRiderb.png");break;
					case "Hela" : s = new ImageIcon("Helab.png");break;
					case "Hulk" : s = new ImageIcon("Hulkb.png");break;
					case "Iceman" : s = new ImageIcon("Icemanb.jpg");break;
					case "Ironman" : s = new ImageIcon("Ironmanb.png");break;
					case "Loki" : s = new ImageIcon("Lokib.jfif");break;
					case "Quicksilver" : s = new ImageIcon("Quicksilverb.png");break;
					case "Spiderman" : s = new ImageIcon("Spidermanb.png");break;
					case "Thor" : s = new ImageIcon("Thorb.png");break;
					case "Venom" : s = new ImageIcon("Venomb.jfif");break;
					case "Yellow Jacket" : s = new ImageIcon("YellowJacketb.png");break;
					default:break;
					}
					JLabel l = new JLabel();
					l.setBounds(70, 65, 100, 100);
					l.setIcon(s);
					board[i][j].add(l);
				}
				}
				else
					board[i][j].removeAll();
			}
		}
		this.repaint();
		this.revalidate();
	}
	
	public void showCurrentInfo(Champion c){
		JFrame f = new JFrame(c.getName()+ "'s Information");
		f.setBounds(0,375,375,500);
		f.setVisible(true);
		JPanel info = new JPanel();
		info.setVisible(true);
		info.setBounds(0,0,375,500);
		info.setLayout(null);
		JTextArea j = new JTextArea();
		j.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 16));
		j.setBounds(25,20,300,200);
		j.setEditable(false);
		String ctype = "";
		if (c instanceof Hero)
			ctype = "Hero";
		else if (c instanceof AntiHero)
		ctype = "AntiHero";
		else 
			ctype= "Villain";
		String total = c.getName()+ "\n" + ctype + "\n" + 
			"Mana = " + c.getMana() + "\n" +
			"Current HP  = " + c.getCurrentHP() + "\n" + 
			"Action Points = " + c.getCurrentActionPoints() + "\n" + 
			"Attack Damage = " + c.getAttackDamage() + "\n" +
			"Attack Range = " + c.getAttackRange();
		j.setText(total);
		info.add(j);
		currentAbilityInfo = new JButton("Champion's Abilities");
		currentAbilityInfo.setBounds(25,250,300,50);
		currentAbilityInfo.setFont(new Font(Font.MONOSPACED, Font.BOLD, 16));
		info.add(currentAbilityInfo);
		currentEffectsInfo = new JButton("Champion's Applied Effects");
		currentEffectsInfo.setBounds(25,350,300,50);
		currentEffectsInfo.setFont(new Font(Font.MONOSPACED, Font.BOLD, 16));
		info.add(currentEffectsInfo);
		f.add(info);
		
		f.revalidate();
		f.repaint();
	}
	
	public void showCurrentAbilities(Champion c){
		JFrame f = new JFrame("Champion's Abilities");
		f.setBounds(1550,150,400,875);
		f.setVisible(true);
		JPanel abilityInfo = new JPanel();
		abilityInfo.setVisible(true);
		abilityInfo.setLayout(null);
		abilityInfo.setBounds(0,0,400,875);
		JTextArea j = new JTextArea();
		j.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 16));
		j.setBounds(10,10,350,825);
		j.setEditable(false);
		int l=0;
		String abilities = "";
		for(int i = 0; i< c.getAbilities().size();i++){
			l= i+1;
			Ability a = c.getAbilities().get(i);
			String typeOf= "";
			if(a instanceof CrowdControlAbility
					&& ((CrowdControlAbility) a).getEffect().getType() == EffectType.DEBUFF)
				typeOf= "Crowd Control Ability of type DEBUFF";
			if(a instanceof CrowdControlAbility
					&& ((CrowdControlAbility) a).getEffect().getType() == EffectType.BUFF)
				typeOf= "Crowd Control Ability of type BUFF";
			if(a instanceof DamagingAbility)
				typeOf= "Damaging Ability ";
			else if(a instanceof HealingAbility)
				typeOf= "Healing Ability ";
			
			abilities += l+") "+a.getName() + "\n"+ 
				typeOf + "\n"+
				"Cast Area is " + a.getCastArea() + "\n"+ 
				"Cast range = " +a.getCastRange() + "\n"+ 
				"Mana Cost = " + a.getManaCost() + "\n"+
				"Action Cost = " + a.getRequiredActionPoints() + "\n"+ 
				"Base Cool Down = "+ a.getBaseCooldown()+ "\n"+ 
				"Current Cool Down = "+ a.getCurrentCooldown()+"\n" + "\n";
					
		}
		j.setText(abilities);
		abilityInfo.add(j);
		f.add(abilityInfo);
		
		f.revalidate();
		f.repaint();
		
	}
	public void showCurrentEffects(Champion c){
		JFrame f = new JFrame("Applied Effects");
		f.setBounds(1550,350,400,400);
		f.setVisible(true);
		JPanel effectsInfo = new JPanel();
		effectsInfo.setVisible(true);
		effectsInfo.setBounds(0,0,400,400);
		effectsInfo.setLayout(null);
		JTextArea j = new JTextArea();
		j.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 16));
		j.setBounds(10,10,350,325);
		j.setEditable(false);
		int l=1;
		String effects = "";
		for(int i = 0; i< c.getAppliedEffects().size();i++){
			effects+= l+") "+ "The Effect name is "+ c.getAppliedEffects().get(i).getName()+ "\n"+
		    "the effect Duration = "+  c.getAppliedEffects().get(i).getDuration()+ "\n" + "\n";
			l++;
		}
		j.setText(effects);
		effectsInfo.add(j);
		f.add(effectsInfo);
		
		f.revalidate();
		f.repaint();
	}
	
	public void showMemberInfo(Champion c, boolean flag, boolean isMember1){
		JFrame f = new JFrame(c.getName()+" "+"Information");
		if(isMember1)
			f.setBounds(0,400,365,600);
		else
			f.setBounds(1550,400,400,600);
		f.setVisible(true);
		JPanel memberInfo = new JPanel();
		memberInfo.setVisible(true);
		memberInfo.setBounds(0,0,365,600);
		memberInfo.setLayout(null);
		JTextArea j = new JTextArea();
		j.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 16));
		j.setBounds(25,25,330,400);
		j.setEditable(false);
		String info = "";
		String status = "";
		String ctype = "";
		
		if (flag)
			status= "Leader of the Team";
		else 
			status = "Member of the Team";
		
		if (c instanceof Hero)
			ctype = "Hero";
		else if (c instanceof AntiHero)
		ctype = "AntiHero";
		else if(c instanceof Villain)
			ctype= "Villain";
		
		int l=1;
		String effects = "";
		for(int i = 0; i< c.getAppliedEffects().size();i++){
			effects+= l+") "+ "The Effect name is "+ c.getAppliedEffects().get(i).getName()+ "\n"+
		    "the effect Duration = "+  c.getAppliedEffects().get(i).getDuration()+ "\n" + "\n";
			l++;
		}
		info = "Name: "+c.getName()+"\n"+ 
			   "Type: " + ctype + "\n" + status + "\n" +
			   "Mana = "+ c.getMana()+ "\n" +
			   "Speed = " + c.getSpeed()+"\n"+
			   "Current HP  = "+ c.getCurrentHP() + "\n" + 
			   "Maximum Action per turn = "+c.getMaxActionPointsPerTurn()+"\n" + 
			   "Attack Damage = "+ c.getAttackDamage()+ "\n" +
			   "Attack range = "+ c.getAttackRange()+ "\n" + "\n" +
			   "Effects: " + "\n" + effects;
		
		j.setText(info);
		memberInfo.add(j);
		f.add(memberInfo);
		
		f.revalidate();
		f.repaint();
	}
	
	public void attackView(){
		attackFrame = new JFrame("Attack");
		attackFrame.setBounds(0,450,365,300);
		attackFrame.setVisible(true);
		JPanel pnlAttack = new JPanel();
		pnlAttack.setBounds(0,0,365,300);
		pnlAttack.setVisible(true);
		pnlAttack.setLayout(null);
		btnLeftAttack = new JButton();
		btnLeftAttack.setIcon(new ImageIcon("ArrowLeft.jpg"));
		btnRightAttack = new JButton();
		btnRightAttack.setIcon(new ImageIcon("ArrowRight.jpg"));
		btnDownAttack = new JButton();
		btnDownAttack.setIcon(new ImageIcon("ArrowDown.jpg"));
		btnUpAttack = new JButton();
		btnUpAttack.setIcon(new ImageIcon("ArrowUp.jpg"));

		btnLeftAttack.setBounds(15,125,100,100);
		btnRightAttack.setBounds(215,125,100,100);
		btnDownAttack.setBounds(115,125,100,100);
		btnUpAttack.setBounds(115,25,100,100);
		pnlAttack.add(btnLeftAttack);
		pnlAttack.add(btnRightAttack);
		pnlAttack.add(btnDownAttack);
		pnlAttack.add(btnUpAttack);
		attackFrame.add(pnlAttack);
		
		attackFrame.revalidate();
		attackFrame.repaint();
	}
	
	public void moveView(){
		moveFrame = new JFrame("Move");
		moveFrame.setBounds(0,450,365,300);
		moveFrame.setVisible(true);
		JPanel pnlMove = new JPanel();
		pnlMove.setBounds(0,0,365,300);
		pnlMove.setVisible(true);
		pnlMove.setLayout(null);
		btnLeft = new JButton();
		btnLeft.setIcon(new ImageIcon("ArrowLeft.jpg"));
		btnRight = new JButton();
		btnRight.setIcon(new ImageIcon("ArrowRight.jpg"));
		btnDown = new JButton();
		btnDown.setIcon(new ImageIcon("ArrowDown.jpg"));
		btnUp = new JButton();
		btnUp.setIcon(new ImageIcon("ArrowUp.jpg"));
		btnLeft.setBounds(15,125,100,100);
		btnRight.setBounds(215,125,100,100);
		btnDown.setBounds(115,125,100,100);
		btnUp.setBounds(115,25,100,100);
		pnlMove.add(btnLeft);
		pnlMove.add(btnRight);
		pnlMove.add(btnDown);
		pnlMove.add(btnUp);
		moveFrame.add(pnlMove);
		
		moveFrame.revalidate();
		moveFrame.repaint();
	}
	public void castAbilityView(Game g){
		castFrame = new JFrame();
		castFrame.setBounds(0,250,365,750);
		castFrame.setVisible(true);
		JPanel details = new JPanel();
		details.setBounds(0,0,365,750);
		details.setVisible(true);
		details.setLayout(null);
		JLabel text = new JLabel("Choose ability:");
		text.setFont(new Font(Font.MONOSPACED, Font.BOLD, 20));
		text.setBounds(10,10,200,100);
		details.add(text);
		champAbilities = new ArrayList<JButton>();
		int y = 100;
		for(Ability a : g.getCurrentChampion().getAbilities()){
			JButton ab = new JButton(a.getName()+" ("+a.getCastArea()+")");
			ab.setName(a.getName());
			ab.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
			champAbilities.add(ab);
			ab.setBounds(50,y,250,100);
			y+=125;
			details.add(ab);
		}
		castFrame.add(details);
		
		castFrame.revalidate();
		castFrame.repaint();
	}
	public void useAbility(Ability a){
		if(a.getCastArea().equals(AreaOfEffect.DIRECTIONAL)){
			direcFrame = new JFrame();
			direcFrame.setBounds(0,450,365,300);
			direcFrame.setVisible(true);
			JPanel pnlDirec = new JPanel();
			pnlDirec.setBounds(0,0,365,300);
			pnlDirec.setVisible(true);
			pnlDirec.setLayout(null);
			btnLeftArea = new JButton();
			btnLeftArea.setIcon(new ImageIcon("ArrowLeft.jpg"));
			btnRightArea = new JButton();
			btnRightArea.setIcon(new ImageIcon("ArrowRight.jpg"));
			btnDownArea = new JButton();
			btnDownArea.setIcon(new ImageIcon("ArrowDown.jpg"));
			btnUpArea = new JButton();
			btnUpArea.setIcon(new ImageIcon("ArrowUp.jpg"));
			btnLeftArea.setName(a.getName());
			btnRightArea.setName(a.getName());
			btnDownArea.setName(a.getName());
			btnUpArea.setName(a.getName());
			btnLeftArea.setBounds(25,125,100,100);
			btnRightArea.setBounds(225,125,100,100);
			btnDownArea.setBounds(125,125,100,100);
			btnUpArea.setBounds(125,25,100,100);
			pnlDirec.add(btnLeftArea);
			pnlDirec.add(btnRightArea);
			pnlDirec.add(btnDownArea);
			pnlDirec.add(btnUpArea);
			direcFrame.add(pnlDirec);
			
			direcFrame.revalidate();
			direcFrame.repaint();
		}
		
		else if(a.getCastArea().equals(AreaOfEffect.SINGLETARGET)){
			singFrame = new JFrame();
			singFrame.setBounds(1550,450,400,450);
			singFrame.setVisible(true);
			JPanel pnlSing = new JPanel();
			pnlSing.setBounds(0,0,400,450);
			pnlSing.setLayout(null);
			pnlSing.setVisible(true);
			JLabel labelP1 = new JLabel();
			JLabel labelP2 = new JLabel();
			targetX = new JTextField();
			targetY = new JTextField();
			
			labelP1.setBounds(25,0,300,50);
			labelP1.setFont(new Font(Font.MONOSPACED, Font.BOLD, 16));
			targetX.setBounds(50,75,200,50);
			targetX.setFont(new Font(Font.MONOSPACED, Font.BOLD, 20));
			targetX.setName(a.getName());
			
			labelP2.setBounds(25,150,300,50);
			labelP2.setFont(new Font(Font.MONOSPACED, Font.BOLD, 16));
			targetY.setBounds(50,225,200,50);
			targetY.setFont(new Font(Font.MONOSPACED, Font.BOLD, 20));
			
			labelP1.setText("Enter target's X coordinate: ");
			labelP2.setText("Enter target's Y coordinate: ");
			pnlSing.add(labelP1);
			pnlSing.add(targetX);
			pnlSing.add(labelP2);
			pnlSing.add(targetY);
			enter = new JButton("Enter");
			enter.setBounds(100,300,100,50);
			pnlSing.add(enter);
			singFrame.add(pnlSing);
			
			singFrame.revalidate();
			singFrame.repaint();
				
		}
		this.revalidate();
		this.repaint();
	}
	
	public void gameOver(Game g){
		this.dispose();
		JFrame win = new JFrame("Game Over");
		win.setLayout(null);
		win.setVisible(true);
		win.setBackground(Color.WHITE);
		win.setBounds(0,0, 2000, 1100);
		ImageIcon image = new ImageIcon("GameOver.png");
		JLabel l = new JLabel();
		l.setBounds(350,50,1200,800);
		l.setPreferredSize(new Dimension(1950,1100));
		l.setIcon(image);
		win.add(l);
		if(g.checkGameOver().equals(g.getFirstPlayer())){
			JLabel s = new JLabel("The Winner is  " + g.getFirstPlayer().getName());
			s.setForeground(Color.RED);
			s.setFont(new Font("MV Boli",Font.ROMAN_BASELINE,100));
			win.add(s);
	    }
		if(g.checkGameOver().equals(g.getSecondPlayer())){	
			JLabel s = new JLabel("The Winner is  " + g.getSecondPlayer().getName());
			s.setForeground(Color.BLUE);
			s.setFont(new Font("MV Boli",Font.ROMAN_BASELINE,100));
			win.add(s);
		}

		win.setDefaultCloseOperation(EXIT_ON_CLOSE);
		win.revalidate();
		win.repaint();
	}
		
}
